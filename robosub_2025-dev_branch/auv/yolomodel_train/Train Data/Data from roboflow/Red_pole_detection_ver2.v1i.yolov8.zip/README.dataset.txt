# Red_pole_detection_ver2 > 2025-07-07 11:54pm
https://universe.roboflow.com/redpoles/red_pole_detection_ver2

Provided by a Roboflow user
License: CC BY 4.0

